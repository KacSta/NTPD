from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib
import os

def retrain_model(**kwargs):
    input_path = "/opt/airflow/data/new_data.csv"
    model_dir = "/opt/airflow/models/"
    
    df = pd.read_csv(input_path)
    X = df.drop("target", axis=1)
    y = df["target"]

    clf = RandomForestClassifier(random_state=42)
    clf.fit(X, y)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
        
    model_path = f"{model_dir}rf_model_{timestamp}.pkl"
    joblib.dump(clf, model_path)
    
    accuracy = clf.score(X, y)
    print(f"Model trained with accuracy: {accuracy}")
    
    return model_path

# Definicja DAG-a
default_args = {
    'owner': 'Kacper',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    'retrain_model_dag',
    default_args=default_args,
    description='DAG do re-trenowania modelu ML',
    schedule='@daily',
    catchup=False
) as dag:

    train_task = PythonOperator(
        task_id='retrain_model_task',
        python_callable=retrain_model,
    )

    train_task