from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib
import os
import shutil

DATA_PATH = "/opt/airflow/data/new_data.csv"
MODEL_DIR = "/opt/airflow/models/"
PROD_DIR = "/opt/airflow/models/production/"
ACCURACY_FILE = "/opt/airflow/models/production/last_accuracy.txt"

def train_and_validate(**kwargs):
    df = pd.read_csv(DATA_PATH)
    X, y = df.drop("target", axis=1), df["target"]

    clf = RandomForestClassifier(random_state=42)
    clf.fit(X, y)
    
    current_accuracy = clf.score(X, y)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    temp_model_path = f"{MODEL_DIR}candidate_model_{timestamp}.pkl"
    joblib.dump(clf, temp_model_path)
    
    kwargs['ti'].xcom_push(key='current_accuracy', value=current_accuracy)
    kwargs['ti'].xcom_push(key='model_path', value=temp_model_path)
    print(f"Candidate model accuracy: {current_accuracy}")

def check_if_better(**kwargs):
    ti = kwargs['ti']
    current_acc = ti.xcom_pull(key='current_accuracy', task_ids='train_task')
    
    old_acc = 0.0
    if os.path.exists(ACCURACY_FILE):
        with open(ACCURACY_FILE, "r") as f:
            old_acc = float(f.read())
    
    print(f"Comparing: New ({current_acc}) vs Old ({old_acc})")
    
    if current_acc > old_acc:
        return 'deploy_model_task'
    return 'keep_as_archive_task'

def deploy_model(**kwargs):
    ti = kwargs['ti']
    new_model_path = ti.xcom_pull(key='model_path', task_ids='train_task')
    current_acc = ti.xcom_pull(key='current_accuracy', task_ids='train_task')
    
    if not os.path.exists(PROD_DIR):
        os.makedirs(PROD_DIR)
        
    shutil.copy(new_model_path, f"{PROD_DIR}production_model.pkl")

    with open(ACCURACY_FILE, "w") as f:
        f.write(str(current_acc))
    print("Model deployed to production!")

with DAG(
    'retrain_model_v2_validation',
    default_args={'owner': 'Kacper', 'start_date': datetime(2024, 1, 1)},
    schedule='@daily',
    catchup=False
) as dag:

    train_task = PythonOperator(
        task_id='train_task',
        python_callable=train_and_validate,
    )

    branch_task = BranchPythonOperator(
        task_id='check_if_better_task',
        python_callable=check_if_better,
    )

    deploy_task = PythonOperator(
        task_id='deploy_model_task',
        python_callable=deploy_model,
    )

    archive_task = BashOperator(
        task_id='keep_as_archive_task',
        bash_command='echo "New model is not better. Keeping current production model."',
    )

    train_task >> branch_task >> [deploy_task, archive_task]